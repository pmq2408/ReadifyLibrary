import React from 'react'

export const StatisticsPage = () => {
    return (
        <div>StatisticsPage</div>
    )
}
